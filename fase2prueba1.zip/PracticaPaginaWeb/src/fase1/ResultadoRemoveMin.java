package fase1;

public class ResultadoRemoveMin<T extends Comparable<T>> {
	T elValor;
	NodoABBPalabras<T> elNodo; 
}
