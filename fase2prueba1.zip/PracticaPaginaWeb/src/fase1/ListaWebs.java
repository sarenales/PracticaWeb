package fase1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListaWebs {
	
	private ArrayList<Web> ListaWebs;
	
	public ListaWebs() {
		ListaWebs = new ArrayList<Web>();
	}
	
	
	public ArrayList<Web> getListaWebs() {
		return ListaWebs;
	}


	public void setListaWebs(ArrayList<Web> listaWebs) {
		ListaWebs = listaWebs;
	}


	/**
	* A�ade una web a la lista
	* @param web: la web a a�adir
	* PRE: web no est� en la lista
	*/
	public void anadirWeb(Web web){
		ListaWebs.add(web);	
	} 


	/**
	* A�ade un enlace a una web de la lista
	* @param idWebOrigen: id de la web de origen (X)
	* @param idWebDestino: id de la web de destino (Y)
	* PRE: las webs con id idWebOrigen e idWebDestino est�n en la lista
	*/
	
	public void anadirEnlace(int idWebOrigen, int idWebDestino){
		Web e= ListaWebs.get(idWebOrigen);
		e.anadirlink(idWebDestino);	
	} 
	
	
}