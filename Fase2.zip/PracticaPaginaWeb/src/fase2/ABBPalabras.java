package fase2;

import java.util.LinkedList;

public class ABBPalabras implements InterfacePalabras{

	NodoABBPalabras root;

	public ABBPalabras() {
		// TODO Auto-generated constructor stub
	}

	// M�TODOS AUXILIARES

	public boolean isEmpty() {
		return this.root == null;
	}

	public void imprimirArbol() {
		if (this.isEmpty())
			System.out.println("*");
		else {
			this.root.imprimirArbol();
			System.out.println();
		}

	}

	/**
	 * A�ade una palabra al �rbol
	 * 
	 * @param palabra: palabra a a�adir
	 */
	public void anadirPalabra(Palabra palabra) {
		if (this.isEmpty()) {
			this.root = new NodoABBPalabras(palabra);
		} else {
//			System.out.println(palabra.palabra + "anadida.");
			this.root.anadirPalabra(palabra);
		}
	}

	/**
	 * Busca una palabra en el �rbol y la devuelve
	 * 
	 * @param sPalabra: texto de la palabra a buscar
	 * @return la Palabra (si est� en el �rbol), null en caso contrario
	 */
	public Palabra buscarPalabra(String sPalabra) {
		if (this.isEmpty())
			return null;
		return this.root.buscarPalabra(sPalabra);
	}

	private LinkedList<Palabra> obtenerPalabrasAEliminar() {
		LinkedList<Palabra> result = new LinkedList<Palabra>();
		if (this.isEmpty())
			return result;
		return this.root.obtenerPalabrasAEliminar();
	}

	private Palabra removeMin() {
		if(this.isEmpty()) return null;
		else {
			ResultadoRemoveMin resul=root.removeMin();
			root=resul.elNodo;
			return resul.elValor;
		}
	}

	/**
	 * Elimina del �rbol la palabra pasada como par�metro Pre: la palabra como mucho
	 * est� una vez en el diccionario
	 * 
	 * @param pal: palabra a eliminar
	 */
	private void eliminarPalabra(Palabra pal) {
		if (!this.isEmpty()) {
			this.root = this.root.eliminarPalabra(pal);
		}
	}

}
