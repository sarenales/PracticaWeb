Esta 3ª fase ha sido realizada por los alumnos de ingeniería informática: Silvia Arenales, Xabier Badiola e Iker García. 

Se ha realizado en la asignatura de Estructura de Datos y Algoritmos en el 2º curso de Ingeniería Informática de la Universidad del País Vasco(EHU).