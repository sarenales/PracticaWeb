package fase2;

public interface InterfacePalabras {

	public void anadirPalabra(Palabra palabra);
	public Palabra buscarPalabra(String sPalabra);
}
