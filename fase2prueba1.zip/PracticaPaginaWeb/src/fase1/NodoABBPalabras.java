package fase1;

import java.util.LinkedList;

public class NodoABBPalabras <T extends Comparable<T>> {
	
	Palabra info;
	NodoABBPalabras<T> left;
	NodoABBPalabras<T> right;

	public NodoABBPalabras(Palabra info) {
		this.info = info;
	}

	public boolean isLeaf() {
		return left == null && right == null;
	}

	public boolean hasLeft() {
		return left != null;
	}

	public boolean hasRight() {
		return right != null;
	}

	public void imprimirArbol() {
		if (this.isLeaf())
			System.out.print("[ " + this.info + " ] ");
		else {
			System.out.print("[ " + info + " ");
			if (this.hasLeft())
				this.left.imprimirArbol();
			else
				System.out.print("* ");
			if (this.hasRight())
				this.right.imprimirArbol();
			else
				System.out.print("* ");
			System.out.print("] ");
		}
	}

	public void anadirPalabra(Palabra palabra) {
		if (palabra.compareTo(this.info) < 0) {// elem debe ir antes que el actual
			if (this.hasLeft())
				this.left.anadirPalabra(palabra);
			else
				this.left = new NodoABBPalabras<T>(palabra);
		} else { // elem debe ir despu�s que el actual
			if (this.hasRight())
				this.right.anadirPalabra(palabra);
			else
				this.right = new NodoABBPalabras<T>(palabra);

		}
	}

	/**
	 * Busca una palabra en el �rbol y la devuelve
	 * 
	 * @param sPalabra: texto de la palabra a buscar
	 * @return la Palabra (si est� en el �rbol), null en caso contrario
	 */
	public Palabra buscarPalabra(String sPalabra) {
		fase1.Palabra res = this.info;
		if (res.equals(sPalabra)) {
			return res;
		}
		if (this.hasLeft())
			res = this.left.buscarPalabra(sPalabra);
		if (this.hasRight())
			res = this.right.buscarPalabra(sPalabra);
		return null;
	}

	/**
	 * Devuelve una lista con todas aquellas palabras del �rbol que no sean palabra
	 * clave de ninguna web
	 * 
	 * @return lista con las palabras a eliminar
	 */
	public LinkedList<Palabra> obtenerPalabrasAEliminar() {
		LinkedList<Palabra> result = new LinkedList<Palabra>();
		
		if(!this.info.esClave()) {
			result.add(this.info);
		}
		
		
		// esto ns
		// if(this.info >3 && this.info <11) {
		// result.add(this.info);
		// }
		if (this.hasLeft())
			result.addAll(this.left.obtenerPalabrasAEliminar());
		if (this.hasRight())
			result.addAll(this.right.obtenerPalabrasAEliminar());
		return result;
	}

	// Elimina el m�nimo (no lo devuelve). Devuelve a d�nde tiene que apuntar el
	// left del
	// padre del nodo actual (o a donde tiene que apuntar root si el actual es la
	// ra�z)
	public ResultadoRemoveMin<T> removeMin() {
		ResultadoRemoveMin<T> resul = new ResultadoRemoveMin<T>();
		
		if(!this.hasLeft()) {
			resul.elValor=(T) this.info;
			resul.elNodo=this.right;
		}
		else { 
		 ResultadoRemoveMin<T> resultadoLeft = this.left.removeMin();
		 this.left=resultadoLeft.elNodo;
		 resul.elValor=resultadoLeft.elValor;
		 resul.elNodo=this;
		}
		return resul;
		
	}
	/**
	 * Elimina del �rbol la palabra pasada como par�metro Pre: la palabra como mucho
	 * est� una vez en el diccionario
	 * 
	 * @param pal: palabra a eliminar
	 */
	public NodoABBPalabras<T> eliminarPalabra(Palabra pal) {
		int comp = pal.compareTo(this.info);
		if (comp == 0) {					// Caso (a): this es el nodo a eliminar
			if (!this.hasLeft())
				return this.right; 			// Caso (a1)
			else if (!this.hasRight())
				return this.left; 			// Caso (a2)
			else {							// Caso (a3): Tiene los dos subarboles, sustituir por el valor m�nimo del
											// subarbol derecho
				ResultadoRemoveMin<T> min = this.right.removeMin();
				this.right = min.elNodo;
				return this;
			}
		} else if (comp < 0) {				// Caso (b) El elemento a eliminar, si est�, estar� en el sub�rbol izq
			if (this.hasLeft())
				this.left = this.left.eliminarPalabra(pal);
			return this;
		} else {							// comp>0: Caso (c) El elemento a eliminar, si est�, estar� en el sub�rbol dcho
			if (this.hasRight())
				this.right = this.right.eliminarPalabra(pal);
			return this;
		}
	}

}
