package fase2;

import java.util.ArrayList;

public class Palabra implements Comparable<Palabra>{

	public String palabra;
	public ArrayList<Web> websPalabra;

	public Palabra(String palabra) {
		this.palabra = palabra;
		websPalabra = new ArrayList<Web>();

	}

	public String getPalabra() {
		return palabra;
	}

	public void setPalabra(String palabra) {
		this.palabra = palabra;
	}


	public ArrayList<Web> getWebsPalabra() {
		return websPalabra;
	}


	public void setWebsPalabra(ArrayList<Web> websPalabra) {
		this.websPalabra = websPalabra;
	}



	public void anadirWeb (Web web) {
		websPalabra.add(web);
	}


	public void imprimirWebs() {

		if(websPalabra.isEmpty()) {
			System.out.println(" No se encuentra ninguna web relacionada.");
		}else {
			for(Web w: websPalabra) {
				System.out.println(w.getIndex()+" "+w.getURL());
			}
		}
	}


	public boolean esClave() {

		if(this.palabra.length() >3 && this.palabra.length()<11) {
			return true;
		}
		return false;
	}

	@Override
	public int compareTo(Palabra pal) {
		int l1 = pal.palabra.length();
		int l2 = this.palabra.length();
		int lmin = Math.min(l1, l2);

		for (int i = 0; i < lmin; i++) {
			int str1 = (int)pal.palabra.toLowerCase().charAt(i);
			int str2 = (int)this.palabra.toLowerCase().charAt(i);

			if (str1 != str2) {
				return str1 - str2;
			}
		}

		if (l1 > l2) return 1;
		else if(l1<l2) return -1;
		else return 0;
	}

}
