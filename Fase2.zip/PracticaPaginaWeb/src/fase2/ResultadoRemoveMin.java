package fase2;

public class ResultadoRemoveMin {
	Palabra elValor;
	NodoABBPalabras elNodo; 
}
